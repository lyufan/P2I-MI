#!/bin/sh
pip install gdown
mkdir pretrained_models
cd pretrained_models
gdown --fuzzy https://drive.google.com/file/d/1bMTNWkh5LArlaWSc_wa8VKyq2V42T2z0/view?usp=sharing
cd ..

